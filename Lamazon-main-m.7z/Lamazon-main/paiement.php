<?php
session_start();

require 'vendor/autoload.php';
\Stripe\Stripe::setApiKey('sk_test_51NuUn4FRtyd6V2C3iEHX38aUhQmWR9lTH4A72BS4mwq85HRklCfE74ugVaoTRSJLCjk8xu360DUfVV13ZMwDGXRF00wSR6lGgZ');

$YOUR_DOMAIN = 'http://localhost/Projet_Boutique-main/projetBoutique/';

if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    $lineItems = [];

    foreach ($_SESSION['cart'] as $row) {
        $productTotal = $row['prix'] * $row['quantite'];
        
        // Ajouter chaque article comme une ligne distincte
        $lineItems[] = [
            'price' => 'price_1OEpQfFRtyd6V2C3ShH12oiV',
            'quantity' => $row['quantite'],
        ];
    }

    $checkout_session = \Stripe\Checkout\Session::create([
        'line_items' => $lineItems,
        'mode' => 'payment',
        'success_url' => $YOUR_DOMAIN . '/success.php',
        'cancel_url' => $YOUR_DOMAIN . '/cancel.php',
    ]);

    header("HTTP/1.1 303 See Other");
    header("Location: " . $checkout_session->url);
} else {
    echo "Le panier est vide ou n'est pas correctement défini.";
}
?>
