
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "boutique";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$stmt = $conn->prepare("INSERT INTO produits (nom, prix, image) VALUES (:nom, :prix, :image)");
$stmt->bindParam(':nom', $_POST['nom']);
$stmt->bindParam(':prix', $_POST['prix']);
$stmt->bindParam(':image', $_POST['image']);

try {
    $stmt->execute();
    echo "Produit ajouté avec succès";
} catch (PDOException $e) {
    echo "Erreur: " . $e->getMessage();
}

$conn = null;
?>