<?php
session_start(); // Démarre une nouvelle session ou reprend une session existante

include "../BDD/config.php"; // Inclut le fichier de configuration de la base de données

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php"); // Redirige vers la page de connexion si non connecté
    exit();
}

$user_id = $_SESSION['user_id']; // Récupère l'ID de l'utilisateur depuis la session

// Récupère les informations de l'utilisateur depuis la base de données
try {
    $sql = "SELECT * FROM users WHERE id = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des informations de l'utilisateur : " . $e->getMessage());
}

// Récupère l'historique des commandes depuis la base de données
try {
    $orderSql = "SELECT * FROM commandes WHERE idUser = :user_id";
    $orderStmt = $conn->prepare($orderSql);
    $orderStmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $orderStmt->execute();
    $orders = $orderStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération de l'historique des commandes : " . $e->getMessage());
}

// Gère la mise à jour du mot de passe
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_password'])) {
    // ... (comme avant)
}

// Gère la déconnexion
if (isset($_GET['logout'])) {
    session_unset(); // Libère toutes les variables de session
    session_destroy(); // Détruit la session
    header("Location: ../Accueil/index.php"); // Redirige vers la page d'accueil après la déconnexion
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Compte</title>
</head>
<body>

<h1>Voulez-vous vous déconnecter ?</h1>

<?php
if ($user) {
    echo '<a href="?logout=true">Se déconnecter</a>'; // Lien pour se déconnecter
    echo '<br>';
    echo '<a href="../Compte/monCompte.php">Revenir en arrière</a>'; // Lien pour revenir sur la page de compte
} else {
    echo "<p>Utilisateur introuvable.</p>"; // Message si aucun utilisateur n'est trouvé
}
?>

</body>
</html>
