// Fonction pour ouvrir une popup de connexion
function ouvrirPopupConnexion() {
    // Définit la largeur et la hauteur de la popup
    var largeur = 300;
    var hauteur = 200;
    // Calcule la position gauche et le haut pour centrer la popup
    var gauche = (window.screen.width / 2) - (largeur / 2);
    var haut = (window.screen.height / 2) - (hauteur / 2);

    // Ouvre la fenêtre de connexion dans une nouvelle popup avec les dimensions et positions calculées
    var fenetreConnexion = window.open("login.html", "fenetreConnexion", "width=" + largeur + ",height=" + hauteur + ",left=" + gauche + ",top=" + haut);
}
