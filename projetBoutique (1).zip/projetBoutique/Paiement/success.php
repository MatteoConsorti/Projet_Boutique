<?php

session_start(); // Assurez-vous de démarrer la session

// Informations de connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "boutique";

try {
    // Création d'une connexion PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Configuration de PDO pour qu'il génère des exceptions en cas d'erreur
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("La connexion à la base de données a échoué : " . $e->getMessage());
}

// Assurez-vous que la session est définie et non vide
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    // Assurez-vous que l'ID utilisateur est disponible dans la session
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];

        // Affichage des données récupérées
        $totalPanier = 0; // Initialiser le montant total du panier

        foreach ($_SESSION['cart'] as $product_id => $row) {
            try {
                // Requête SQL pour insérer les données dans la table "commandes"
                $sql = "INSERT INTO commandes (idUser, nom_produit, quantite, prix, date_commande) VALUES (:idUser, :nom_produit, :quantite, :prix, current_timestamp())";
                $stmt = $conn->prepare($sql);

                // Liaison des paramètres avec les valeurs
                $stmt->bindParam(':idUser', $user_id, PDO::PARAM_INT);
                $stmt->bindParam(':nom_produit', $row['nom'], PDO::PARAM_STR);
                $stmt->bindParam(':quantite', $row['quantite'], PDO::PARAM_INT);
                $stmt->bindParam(':prix', $row['prix'], PDO::PARAM_STR);

                // Exécution de la requête
                $stmt->execute();
            } catch (PDOException $e) {
                die("Erreur lors de l'insertion des données : " . $e->getMessage());
            }

            // Accumuler le montant total du panier
            $totalPanier += $row['prix'] * $row['quantite'];
        }
    } else {
        echo "Erreur : L'ID de l'utilisateur n'est pas défini dans la session.";
    }

        // Unset SESSION Panier
        unset($_SESSION['cart']);
}

// Fermeture de la connexion PDO
$conn = null;
?>



<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commande Réussie</title>
</head>
<body>

<?php
    echo "<h1>Votre commande a été effectuée avec succès!</h1>";
    // Supprimez la variable de session pour éviter son affichage répété
    unset($_SESSION['order_success']);
?>

<a href="../Accueil/index.php"><button>Revenir à l'accueil</button></a>

</body>
</html>
