<?php
session_start(); // Démarre ou reprend une session existante

// Inclut le chargeur automatique pour Stripe, permettant d'utiliser les classes Stripe sans inclure manuellement leurs fichiers
require '../ProjetBoutique/vendor/autoload.php';

// Configure la clé secrète de Stripe utilisée pour authentifier les requêtes à l'API
\Stripe\Stripe::setApiKey('sk_test_51NuUn4FRtyd6V2C3iEHX38aUhQmWR9lTH4A72BS4mwq85HRklCfE74ugVaoTRSJLCjk8xu360DUfVV13ZMwDGXRF00wSR6lGgZ');

$YOUR_DOMAIN = 'http://localhost/projetBoutique/'; // Définit le domaine de base pour les URL de redirection

// Vérifie si le panier existe dans la session et s'il est un tableau
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    $totalQuantity = 0; // Initialisation de la quantité totale
    $totalAmount = 0; // Initialisation du montant total

    // Parcourt chaque élément du panier pour calculer la quantité totale et le montant total
    foreach ($_SESSION['cart'] as $row) {
        $totalQuantity += $row['quantite'];
        $productTotal = $row['prix'] * $row['quantite'];
        $totalAmount += $productTotal;
    }

    // Envoie le montant total au navigateur via JavaScript pour une éventuelle utilisation
    echo "<script>
        var totalAmount = $totalAmount;
    </script>";

    // Crée une session de paiement Stripe avec les informations du panier
    $checkout_session = \Stripe\Checkout\Session::create([
        'line_items' => [[
            'price' => 'price_1OEpQfFRtyd6V2C3ShH12oiV', // ID de prix du produit configuré dans le tableau de bord Stripe
            'quantity' => $totalAmount, // Utilise le montant total comme quantité (peut nécessiter une logique différente en fonction de l'implémentation)
        ]],
        'mode' => 'payment', // Définit le mode de la session de paiement pour le paiement direct
        'success_url' => $YOUR_DOMAIN . 'Paiement/success.php', // URL de redirection après un paiement réussi
        'cancel_url' => $YOUR_DOMAIN . '/cancel.php', // URL de redirection en cas d'annulation du paiement
    ]);

    // Redirige le client vers la session de paiement Stripe
    header("HTTP/1.1 303 See Other");
    header("Location: " . $checkout_session->url);
} else {
    echo "Cart is empty or not properly set."; // Message affiché si le panier est vide ou mal configuré
}
?>
