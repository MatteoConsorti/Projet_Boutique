<?php
// Paramètres de connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "boutique";

try {
    // Tentative de connexion à la base de données en utilisant PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Configuration du mode d'erreur pour obtenir des exceptions en cas d'erreur
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Arrêt du script et affichage du message d'erreur si la connexion échoue
    die("Connection failed: " . $e->getMessage());
}

// Préparation de la requête SQL d'insertion avec des paramètres nommés
$stmt = $conn->prepare("INSERT INTO produits (nom, prix, image) VALUES (:nom, :prix, :image)");

// Association des valeurs envoyées via POST aux paramètres nommés de la requête
// Sécurisation contre les injections SQL
$stmt->bindParam(':nom', $_POST['nom']);
$stmt->bindParam(':prix', $_POST['prix']);
$stmt->bindParam(':image', $_POST['image']);

try {
    // Exécution de la requête d'insertion
    $stmt->execute();
    // Affichage d'un message de succès si l'insertion a réussi
    echo "Produit ajouté avec succès";
} catch (PDOException $e) {
    // Affichage d'un message d'erreur en cas d'échec de l'insertion
    echo "Erreur: " . $e->getMessage();
}

// Fermeture de la connexion à la base de données
$conn = null;
?>
