<!DOCTYPE html>
<html>
<head>
    <title>Administration</title>
    <!-- Lien vers la feuille de style CSS pour la mise en page -->
    <link rel="stylesheet" href="Admin.css">
</head>
<body>

    <!-- Titre de la page d'administration -->
    <h1>Administration</h1>

    <!-- Formulaire d'ajout de produit -->
    <form action="AjouterProduits.php" method="post" style="width: 20%; padding: 10px" >
        <!-- Champ pour le nom du produit -->
        <label for="nom">Nom du produit:</label>
        <input type="text" id="nom" name="nom" required>
        <br>
        <!-- Champ pour le prix du produit -->
        <label for="prix">Prix du produit:</label>
        <input type="number" id="prix" name="prix" min="0" step="0.01" required>
        <br>
        <!-- Champ pour l'image du produit -->
        <label for="image">Image du produit:</label>
        <input type="text" id="image" name="image" required>
        <br><br>
        <!-- Bouton pour soumettre le formulaire -->
        <input type="submit" value="Ajouter le produit">
    </form>

    <!-- Section affichage des produits -->
    <h2>Produits</h2>
    <div class="products">
        <!-- La liste des produits sera générée ici par PHP -->
    </div>

    <!-- Lien de retour à la page d'accueil -->
    <a href="../Accueil/index.php"><button>Retourner à l'accueil</button></a>

</body>
</html>

<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "boutique";

try {
    // Tentative de connexion à la base de données
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Configuration des options d'erreur pour PDO
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Gestion de l'échec de la connexion
    die("Connection failed: " . $e->getMessage());
}

// Requête SQL pour sélectionner les produits de la base de données
$sql = "SELECT id_produit, nom, prix, image FROM produits";
$stmt = $conn->prepare($sql);
$stmt->execute();

// Vérification si des produits sont retournés
if ($stmt->rowCount() > 0) {
    // Boucle pour afficher chaque produit
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "
        <div class='product'>
            <img src='" . $row["image"] . "' alt='" . $row["nom"] . "'>
            <h2>" . $row["nom"] . "</h2>
            <p>Prix: " . $row["prix"] . " €</p>
            <!-- Formulaire pour supprimer le produit -->
            <form action='SupprimerProduits.php' method='post'>
                <input type='hidden' name='id' value='" . $row["id_produit"] . "'>
                <button type='submit'>Supprimer le produit</button>
            </form>
        </div>
        ";
    }
    
} else {
    // Message si aucun produit n'est trouvé
    echo "0 résultats";
}

// Traitement du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Vérification de l'action à réaliser
    if (isset($_POST["action"])) {
        $action = secure_data($_POST["action"]);

        // Ajout d'un produit
        if ($action == "add_product") {
            $nom = secure_data($_POST["nom"]);
            $prix = secure_data($_POST["prix"]);
            $image = secure_data($_POST["image"]);

            // Préparation et exécution de la requête SQL d'insertion
            $sql = "INSERT INTO produits (nom, prix, image) VALUES (:nom, :prix, :image)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':nom', $nom);
            $stmt->bindParam(':prix', $prix);
            $stmt->bindParam(':image', $image);

            try {
                $stmt->execute();
                echo "Produit ajouté avec succès";
            } catch (PDOException $e) {
                // Gestion de l'erreur lors de l'ajout du produit
                echo "Erreur: " . $e->getMessage();
            }
        }
    }
}

// Fermeture de la connexion à la base de données
$conn = null;

?>
