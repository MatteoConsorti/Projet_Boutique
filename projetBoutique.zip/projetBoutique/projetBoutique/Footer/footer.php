<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Untitled</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="footer.css">
</head>

    <div class="footer-dark">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="lien"></a></li>
                            <li><a href="lien"></a></li>
                            <li><a href="lien">lien3</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>About</h3>
                        <ul>
                            <li><a href="https://twitter.com/Lamazon03">X</a></li>
                            <li><a href="https://www.instagram.com/lamazon03">instagram</a></li>
                            <li><a href="lien">lien3</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>Lamazon</h3>
                        <p>Lamazon la vie moins cher et en rose </p>
                    </div>
                    <div class="col item social"></a><a href="https://twitter.com/Lamazon03"><i class="icon ion-social-twitter"></i></a><a href="https://www.instagram.com/lamazon03"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                
                <div class="content">
                    <p></p>
                <a href="index.php"><img src="images/logo.jpg"></a>
                </div>
                
            </div><h3><center>&copy; Copyright - tout droits réservé - 2024</center></h3>
        </footer>
    </div>
</html>