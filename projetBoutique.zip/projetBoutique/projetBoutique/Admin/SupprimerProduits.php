<?php
// SupprimerProduits.php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "boutique";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $id = $_POST['id'];
        $sql = "DELETE FROM produits WHERE id_produit = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        header("Location: Admin.php"); // Rediriger après la suppression
        exit();
    } catch (PDOException $e) {
        die("Erreur: " . $e->getMessage());
    } finally {
        $conn = null;
    }
} else {
    header("Location: Admin.php"); // Rediriger si l'ID n'est pas présent dans la requête
    exit();
}

?>
