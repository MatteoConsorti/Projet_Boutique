<!DOCTYPE html>
<html>
<head>
    <title>Administration</title>
    <link rel="stylesheet" href="Admin.css">
</head>
<body>

    <h1>Administration</h1>

    <!-- Formulaire d'ajout de produit -->
    <form action="AjouterProduits.php" method="post" style="width: 20%; padding: 10px" >
        <label for="nom">Nom du produit:</label>
        <input type="text" id="nom" name="nom" required>
        <br>
        <label for="prix">Prix du produit:</label>
        <input type="number" id="prix" name="prix" min="0" step="0.01" required>
        <br>
        <label for="image">Image du produit:</label>
        <input type="text" id="image" name="image" required>
        <br><br>
        <input type="submit" value="Ajouter le produit">
    </form>

    

    <!-- Liste des produits -->
    <h2>Produits</h2>

    <div class="products">
        <!-- List of products from the database -->
    </div>

    <a href="../index.php"><button>Retourner à l'accueil</button></a>


</body>


</html>


<?php
// Création de la connexion
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "boutique";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$sql = "SELECT id_produit, nom, prix, image FROM produits";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "
        <div class='product'>
            <img src='" . $row["image"] . "' alt='" . $row["nom"] . "'>
            <h2>" . $row["nom"] . "</h2>
            <p>Prix: " . $row["prix"] . " €</p>
            <form action='SupprimerProduits.php' method='post'>
                <input type='hidden' name='id' value='" . $row["id_produit"] . "'>
                <button type='submit'>Supprimer le produit</button>
            </form>
        </div>
        ";
    }
    
} else {
    echo "0 résultats";
}


// Gestion des formulaires
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["action"])) {
        $action = secure_data($_POST["action"]);

        if ($action == "add_product") {
            $nom = secure_data($_POST["nom"]);
            $prix = secure_data($_POST["prix"]);
            $image = secure_data($_POST["image"]);

            $sql = "INSERT INTO produits (nom, prix, image) VALUES (:nom, :prix, :image)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':nom', $nom);
            $stmt->bindParam(':prix', $prix);
            $stmt->bindParam(':image', $image);

            try {
                $stmt->execute();
                echo "Produit ajouté avec succès";
            } catch (PDOException $e) {
                echo "Erreur: " . $e->getMessage();
            }
        }
    }
}


// Fermeture de la connexion
$conn = null;

?>



