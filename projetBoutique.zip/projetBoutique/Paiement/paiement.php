<?php
session_start();

require '../ProjetBoutique/vendor/autoload.php';
\Stripe\Stripe::setApiKey('sk_test_51NuUn4FRtyd6V2C3iEHX38aUhQmWR9lTH4A72BS4mwq85HRklCfE74ugVaoTRSJLCjk8xu360DUfVV13ZMwDGXRF00wSR6lGgZ');

$YOUR_DOMAIN = 'http://localhost/projetBoutique/';

if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    $totalQuantity = 0;
    $totalAmount = 0;

    foreach ($_SESSION['cart'] as $row) {
        $totalQuantity += $row['quantite'];
        $productTotal = $row['prix'] * $row['quantite'];
        $totalAmount += $productTotal;
    }

    echo "<script>
        var totalAmount = $totalAmount;
    </script>";

    $checkout_session = \Stripe\Checkout\Session::create([
        'line_items' => [[
            'price' => 'price_1OEpQfFRtyd6V2C3ShH12oiV',
            'quantity' => $totalAmount, 
        ]],
        'mode' => 'payment',
        'success_url' => $YOUR_DOMAIN . 'Paiement/success.php',
        'cancel_url' => $YOUR_DOMAIN . '/cancel.php',
    ]);

    header("HTTP/1.1 303 See Other");
    header("Location: " . $checkout_session->url);
} else {
    echo "Cart is empty or not properly set.";
}
?>
