function openLoginPopup() {
    var width = 300;
    var height = 200;
    var left = (window.screen.width / 2) - (width / 2);
    var top = (window.screen.height / 2) - (height / 2);

    var loginWindow = window.open("login.html", "loginWindow", "width=" + width + ",height=" + height + ",left=" + left + ",top=" + top);
}