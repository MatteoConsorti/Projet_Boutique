<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "boutique";

// Déconnexion
if (isset($_GET['logout']) && $_GET['logout'] == true) {
    session_start();
    session_destroy();
    header("Location: ../index.php"); // Rediriger vers l'accueil après déconnexion
    exit();
}

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("La connexion à la base de données a échoué : " . $e->getMessage());
}

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $username = $_POST["username"];

        $stmt = $conn->prepare("SELECT id, username, password, droit FROM users WHERE username = ?");
        $stmt->execute([$username]);

        $user = $stmt->fetch();

        if ($user) {
            $controle = password_verify($_POST["password"], $user['password']);

            if ($controle) {
                $_SESSION["user_id"] = $user["id"];
                $_SESSION["user_username"] = $user["username"];

                if ($user['droit'] >= 5) {
                    echo 'Vous êtes connecté en tant qu\'administrateur. Accéder à la page : ';
                    ?>
                    <a href="../Admin/Admin.php"><button>Page admin</button></a>
                    <?php
                } else {
                    echo 'Vous êtes connecté. Accéder à la page : ';
                    ?>
                    <a href="../Compte/moncompte.php"><button>Revenir à la page d'accueil</button></a>
                    <a href="../Paiement/paiement.php"><button>Procéder au paiement</button></a>
                    <?php
                }
                exit;
            } else {
                $erreur = "Nom d'utilisateur ou mot de passe incorrect.";
            }
        } else {
            $erreur = "Nom d'utilisateur ou mot de passe incorrect.";
        }
    } else {
        $erreur = "Veuillez fournir un nom d'utilisateur et un mot de passe.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de Connexion</title>
    <link rel="stylesheet" href="connexion.css">
    <script src="script.js"></script>
</head>
<body>
    <h2 style="text-align: center">Connexion</h2>
    
    <?php if(isset($erreur)) { ?>
        <p style="color:red;"><?php echo $erreur; ?></p>
    <?php } ?>

    <form id="loginForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="username">Nom d'utilisateur:</label>
        <input type="text" name="username" required><br>

        <label for="password">Mot de passe:</label>
        <input type="password" name="password" required><br>

        <button>Se Connecter</button>
        </form>
  

</body>
</html>
