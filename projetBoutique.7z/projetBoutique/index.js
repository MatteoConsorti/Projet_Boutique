/*

// Get the modal
var modal = document.getElementById("modal");

// Get the button that opens the modal
var btn = document.getElementById("details-btn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close-button")[0];



// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

*/


/*Pop-up*/

// Obtenez l'image et insérez-la dans la modal - utilisez son "alt" comme texte
var button = document.getElementById("details-btn");
var modal = document.getElementById("modal");
var span = document.getElementsByClassName("close-button")[0];

// Quand l'utilisateur clique sur l'image, ouvrez la modal
button.onclick = function(){
  button.style.display = "block";
}

// Quand l'utilisateur clique sur (x), fermez la modal
span.onclick = function() {
  modal.style.display = "none";
}

// Quand l'utilisateur clique n'importe où en dehors de la modal, fermez-la
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}