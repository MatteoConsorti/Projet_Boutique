<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "boutique";

// Traitement de la déconnexion
if (isset($_GET['logout']) && $_GET['logout'] == true) {
    session_start();
    session_destroy();
    header("Location: ../index.php"); // Redirection vers la page d'accueil après la déconnexion
    exit();
}

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("La connexion à la base de données a échoué : " . $e->getMessage());
}

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $username = $_POST["username"];

        $stmt = $conn->prepare("SELECT id, username, password, droit FROM users WHERE username = ?");
        $stmt->execute([$username]);

        $user = $stmt->fetch();

        if ($user) {
            $controle = password_verify($_POST["password"], $user['password']);

            if ($controle) {
                $_SESSION["user_id"] = $user["id"];
                $_SESSION["user_username"] = $user["username"];

                // Redirection en fonction du niveau de droits de l'utilisateur
                if ($user['droit'] >= 5) {
                    echo 'Vous êtes connecté en tant qu\'administrateur. Accéder à la page : ';
                    ?>
                    <a href="../Admin/Admin.php"><button>Page admin</button></a>
                    <?php
                } else {
                    echo 'Vous êtes connecté. Accéder à la page : ';
                    ?>
                    <a href="../Compte/moncompte.php"><button>Revenir à la page d'accueil</button></a>
                    <a href="../Paiement/paiement.php"><button>Procéder au paiement</button></a>
                    <?php
                }
                exit;
            } else {
                $erreur = "Nom d'utilisateur ou mot de passe incorrect.";
            }
        } else {
            $erreur = "Nom d'utilisateur ou mot de passe incorrect.";
        }
    } else {
        $erreur = "Veuillez fournir un nom d'utilisateur et un mot de passe.";
    }
}
?>
