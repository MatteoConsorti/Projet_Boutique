<?php

// Affiche un message d'alerte en cas de création réussie du compte
if ($showAlert) {
    echo ' <div class="alert alert-success 
            alert-dismissible fade show" role="alert">
            <strong>Success!</strong> Your account is 
            now created and you can login. 
            <button type="button" class="close"
                data-dismiss="alert" aria-label="Close"> 
                <span aria-hidden="true">×</span> 
            </button> 
        </div> ';
}

// Affiche un message d'erreur personnalisé en cas d'échec
if ($showError) {
    echo ' <div class="alert alert-danger 
            alert-dismissible fade show" role="alert"> 
        <strong>Error!</strong> ' . $showError . '
       <button type="button" class="close" 
            data-dismiss="alert aria-label="Close">
            <span aria-hidden="true">×</span> 
       </button> 
     </div> ';
}

// Affiche un message si le nom d'utilisateur existe déjà
if ($exists) {
    echo ' <div class="alert alert-danger 
            alert-dismissible fade show" role="alert">
        <strong>Error!</strong> ' . $exists . '
        <button type="button" class="close" 
            data-dismiss="alert" aria-label="Close"> 
            <span aria-hidden="true">×</span> 
        </button>
       </div> ';
}

// Inclut l'en-tête de la page (s'assurer que le fichier 'header.php' contient les éléments d'en-tête nécessaires)
include ('header.php');
?>

<div style="border: solid 3px #00ced1; padding-bottom: 5%" class="container my-4 ">

    <h1 class="text-center">Inscrivez-Vous ici !</h1>
    <form action="Inscription.php" method="post">
        <div class="form-group">
            <label for="username">Nom d'utilisateur</label>
            <input type="text" class="form-control" id="username" name="username" aria-describedby="emailHelp">
        </div>

        <div class="form-group">
            <label for="password">Mot de passe</label>
            <div class="input-group">
                <input type="password" class="form-control" id="password" name="password">
                <div class="input-group-append" style="margin-left:2%">
                    <!-- Ici, vous pouvez ajouter un bouton pour afficher/masquer le mot de passe -->
                </div>
            </div>
            <progress id="password-strength" max="100" value="0"></progress>
            <!-- Ajoutez l'élément p pour le commentaire de force du mot de passe ici -->
            <p id="password-comment"></p>
        </div>

        <div class="form-group">
            <label for="cpassword">Confirmez le mot de passe</label>
            <input type="password" class="form-control" id="cpassword" name="cpassword" >
            <small id="emailHelp" class="form-text text-muted">
                ⚠ Soyez attentif à utiliser les 2 mêmes mots de passe
            </small>
        </div>

        <button type="submit" class="btn btn-primary">Valider !</button>
    </form>

    <p style="padding-top: 3% "></p>
    <button style="margin-left: 40%" class="btn btn-primary">
        <!-- Utilisez directement un lien ici pour une meilleure pratique -->
        <a href="connexion.php" style="color: white">
            Vous avez déjà un compte ? <br>Connectez-vous pour procéder au paiement
        </a>
    </button>
</div>

<!-- Inclusion de jQuery (nécessaire pour Bootstrap et certains comportements JS) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
    crossorigin="anonymous"></script>

<!-- Script JS pour la manipulation du DOM et validation côté client -->
<script src="Inscription.js"></script>

<!-- Script pour fonctionnalités additionnelles comme l'affichage/masquage du mot de passe -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // S'assurer que l'élément #togglePassword existe dans le formulaire pour utiliser ce script
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function(e) {
            // Logique pour basculer entre le type de champ de mot de passe (afficher/masquer)
        });
    });
</script>
</body>
</html>
