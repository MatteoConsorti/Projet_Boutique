<?php
session_start();

require("header.php");

include "../BDD/config.php";

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: ../Connexion/connexion.php"); // Redirection vers la page de connexion si non connecté
    exit();
}

$user_id = $_SESSION['user_id'];

// Récupération des informations de l'utilisateur depuis la base de données
try {
    $sql = "SELECT * FROM users WHERE id = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des informations de l'utilisateur : " . $e->getMessage());
}

// Récupération de l'historique des commandes depuis la base de données
try {
    $orderSql = "SELECT * FROM commandes WHERE idUser = :user_id";
    $orderStmt = $conn->prepare($orderSql);
    $orderStmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $orderStmt->execute();
    $orders = $orderStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération de l'historique des commandes : " . $e->getMessage());
}

// Traitement de la mise à jour du mot de passe
$password_update_success = $password_error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Validation du nouveau mot de passe
    if (strlen($new_password) < 8) {
        $password_error = "Le mot de passe doit contenir au moins 8 caractères.";
    } elseif ($new_password != $confirm_password) {
        $password_error = "Les mots de passe ne correspondent pas.";
    } else {
        // Hachage du nouveau mot de passe avant son stockage dans la base de données
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Mise à jour du mot de passe de l'utilisateur dans la base de données
        try {
            $updatePasswordSql = "UPDATE users SET password = :hashed_password WHERE id = :user_id";
            $updatePasswordStmt = $conn->prepare($updatePasswordSql);
            $updatePasswordStmt->bindParam(':hashed_password', $hashed_password, PDO::PARAM_STR);
            $updatePasswordStmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $updatePasswordStmt->execute();

            // Message de succès de la mise à jour du mot de passe
            $password_update_success = "Mot de passe mis à jour avec succès!";
        } catch (PDOException $e) {
            die("Erreur lors de la mise à jour du mot de passe : " . $e->getMessage());
        }
    }
}
?>
